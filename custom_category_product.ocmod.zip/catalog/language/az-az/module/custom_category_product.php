<?php 

// text
$_['text_text'] = "Text";